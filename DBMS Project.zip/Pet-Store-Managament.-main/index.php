<html lang="en-us" div="ltr">
<title> Claws & Paws </title>
  <link rel="stylesheet" href="index.css">
</head>

<body class="bg">
  <center>
   <header>
   <meta http-equiv="Cache-control" content="no-cache">
      <nav>
        <img class="img" height="100px" width="310px" alt="" src="logo FL final w.svg">
      </nav>
    </header>
    <!-- <br><br><br><br> -->
    <div class="card">
         <br><br>       
        <div class="flex-container">        
                <div>
                    <img class="img" height="200px" width="200px" alt="" src="cust.svg">
                    <br><br>
                    <input type="button" value="Customer Login" class="btn" onclick="window.location.href='customer.php';"/>
                </div>
                <div>
                    <img class="img" height="200px" width="190px" alt="" src="admin.svg">
                    <br><br>
                    <input type="button" value="Admin Login" class="btn" onclick="window.location.href='admin.php';"/>
                </div>    
        </div>
    </div>
  </center>
</body>
</html>

