# Pet-Store-Managament.

This project is mainly focused on Database concepts to manage the inventory of the pet shop, where the owner/admin can manage all customers, suppliers & pets details in one place.
The technologies used in building this website are HTML, CSS, PHP Mysql server.
